// Hp Display

var HpDisplay = new Display();
HpDisplay.setBackground("per line");
HpDisplay.setRenderLoc(302, 160);

register("chat", "hpd")
  .setCriteria("   &r&c&l[ &r&f&lHP &r&c&l]   &r&c${name} &r&7[&r&4${message}&r&7]&r")

function hpd(name, message, event) {
  cancel(event)
  HpDisplay.setLine(0,
    " &c" + name + " "
  )
  HpDisplay.setLine(1,
    " &4" + message + " "
  )
}

register("chat", "hpda")
  .setCriteria("   &r&f&l[ &r&6&lR&r&b&lD &r&f&l]   ${message} &r&f전리품을 획득하셨습니다.&r")

function hpda(message, event) {
  cancel(event)
  HpDisplay.setLine(1,
    " " + message + " "
  )
}

register("chat", "hpd2")
  .setCriteria(" &r&c${name}를 멀리서 공격하면 &r&4&l&o&n${message}&r&c의 피해를 받습니다!&r")

register("chat", "hpd2")
  .setCriteria(" &r&c${name}을 멀리서 공격하면 &r&4&l&o&n${message}&r&c의 피해를 받습니다!&r")

function hpd2(name, message, event) {
  cancel(event)
  HpDisplay.setLine(2,
    " &7미근접 패널티 &c" + name + " &4" + message + " "
  )
}

register("chat", "hpd3")
  .setCriteria(" &r&e${name}를 가까이에서 공격해 &r&6&l&o${message}&r&e의 추가피해를 입혔습니다!&r")

register("chat", "hpd3")
  .setCriteria(" &r&e${name}을 가까이에서 공격해 &r&6&l&o${message}&r&e의 추가피해를 입혔습니다!&r")

function hpd3(name, message, event) {
  cancel(event)
  HpDisplay.setLine(2,
    " &7근접 보너스 &e" + name + " &6" + message + " "
  )
}

register("chat", "hpd4")
  .setCriteria(" &r&6&l[!] &r&5&o저주&r&7 효과로 피해량이 25% 감소합니다. &r&a(남은 시간: ${message})&r")

function hpd3(message, event) {
  cancel(event)
  HpDisplay.setLine(2,
    " &5&o저주 &a" + message + "초 &7(피해 25% 감소)  "
  )
}

register("chat", "cooltd")
  .setCriteria("   &r&f&l[ &r&6&lR&r&b&lD &r&f&l]   &r&f재사용 대기시간이 &r&e&l${message}&r&f 남았습니다.&r")

register("chat", "cooltd2")
  .setCriteria("   &r&f&l[ &r&6&lR&r&b&lD &r&f&l]   &r&f재사용 대기시간이 &r&c&l${message}&r&f 남았습니다.&r")

function cooltd(message, event) {
  cancel(event)
  HpDisplay.setLine(3,
    " &e좌 &7쿨타임 &e&l" + message + " "
  )
}
function cooltd2(message, event) {
  cancel(event)
  HpDisplay.setLine(3,
    " &c우 &7쿨타임 &c&l" + message + " "
  )
}


register("command", "re")
  .setName("re")
function re() {
  HpDisplay.setLine(0,
    ""
  )
  HpDisplay.setLine(1,
    ""
  )
  HpDisplay.setLine(2,
    ""
  )
  HpDisplay.setLine(3,
    ""
  )
}





// Actionbar Display

// var ACBDisplay = new Display();
// ACBDisplay.setBackground("per line");
// ACBDisplay.setRenderLoc(210, 270);

register("chat", "shpd")
  .setCriteria(" &r&e&l[SHOP] &r&f${name} &r&7&l:: &r&f${message}&r&f를 ${m1}&r&f로 교환하셨습니다.&r")

register("chat", "shpd")
  .setCriteria(" &r&e&l[SHOP] &r&f${name} &r&7&l:: &r&f${message}&r&f를 ${m1}&r&f로 조합하셨습니다.&r")

register("chat", "shpd")
  .setCriteria(" &r&e&l[SHOP] &r&f${name} &r&7&l:: &r&f${message}&r&f를 ${m1}&r&f로 분해하셨습니다.&r")

register("chat", "shpd2")
  .setCriteria(" &r&e&l[SHOP] &r&f${name} &r&7&l:: &r&f${message} 부족합니다.&r")

function shpd(name, message, m1, event) {
  cancel(event)
  HpDisplay.setLine(0,
    name
  )
  HpDisplay.setLine(0,
    " &e[S] &f" + message + " &7➜ &f" + m1 + " "
  )
  HpDisplay.setLine(1,
    ""
  )
  HpDisplay.setLine(2,
    ""
  )
  HpDisplay.setLine(3,
    ""
  )
}

function shpd2(name, message, event) {
  cancel(event)
  HpDisplay.setLine(0,
    name
  )
  HpDisplay.setLine(0,
    " &e[S] &f" + message + " 부족함. "
  )
  HpDisplay.setLine(1,
    ""
  )
  HpDisplay.setLine(2,
    ""
  )
  HpDisplay.setLine(3,
    ""
  )
}



register("chat", "bsd")
  .setCriteria(" &r&b${name} 처치 보상이 지급되었습니다.&r")

function bsd(name, event) {
  cancel(event)
  HpDisplay.setLine(0,
    " &b" + name + " 처치 완료  "
  )
  HpDisplay.setLine(1,
    ""
  )
  HpDisplay.setLine(2,
    ""
  )
  HpDisplay.setLine(3,
    ""
  )
}






// register("command", "ra")
//   .setName("ra")
// function ra() {
//   ACBDisplay.setLine(0,
//     ""
//   )
//   ACBDisplay.setLine(1,
//     ""
//   )
//   ACBDisplay.setLine(2,
//     ""
//   )
// }



// v2 checked successful

register("chat", "sellers") 
.setCriteria(" &8&l(&6&l&o장사글&8&l) &f&l${name} &8&l| &b&l[ &f${message} &b&l]&r")

function sellers(name, message, event) {
cancel(event)
ChatLib.chat(" &6" + name + " &7" + message)
}






register("chat", "afks") 
  .setCriteria(" &r&3&l[자동잠수] &r&7&l- &r&b${message}&r&b명&r&7의 플레이어가 잠수대로 이동되었습니다.&r")
  
function afks(message, event) {
  cancel(event)
  ChatLib.chat(" &3AFK WARP &b" + message)
}





register("chat", "vote") 
  .setCriteria(" &d&l&o<서버추천> &f&l${name} &f님이 &aminelist.kr&f에서 &b추천&f해주셨습니다! &7[/추천] ${message}")
  
function vote(name, event) {
  cancel(event)
  ChatLib.chat(" &a✔ &7" + name)
}

register("chat", "vote2")
  .setCriteria(" &d&l&o<서버추천> &f&l${name} &f님이 &bmine.page&f에서 &b추천&f해주셨습니다! &7[/추천] ${message}")
  
function vote2(name, event) {
  cancel(event)
  ChatLib.chat(" &b✔ &7" + name)
}




register("chat", "upicbox") // 유픽박
  .setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &b&l&o<&f&l&o유픽박스&5&l&o> &e${name} &7&l>&7>&l> ${message}&r")
  
function upicbox(name, message, event) {
  cancel(event)
  ChatLib.chat(" &5<&7" + name + "&b> &7" + message)
}

register("chat", "blockbox") // 블박
  .setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &a&l&o<&f&l&o블럭박스&a&l&o> &e${name} &7&l>&7>&l> ${message}&r")
  
function blockbox(name, message, event) {
  cancel(event)
  ChatLib.chat(" &a<&7" + name + "&a> &7" + message)
}

register("chat", "epicbox") // 에픽박
  .setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &5&l&o<&f&l&o에픽박스&5&l&o> &e${name} &7&l>&7>&l> ${message}&r")
  
function epicbox(name, message, event) {
  cancel(event)
  ChatLib.chat(" &5<&7" + name + "&5> &7" + message)
}

register("chat", "uqbox") // 유닠박
  .setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &b&l&o<&f&l&o유니크박스&b&l&o> &e${name} &7&l>&7>&l> ${message}&r")
  
function uqbox(name, message, event) {
  cancel(event)
  ChatLib.chat(" &b<&7" + name + "&b> &7" + message)
}


register("chat", "tbox") // 정각보상
  .setCriteria(" &r&f&l[ &r&6&lR&r&b&lD &r&f&l] &r&7&l- &r&f정각보상에서 ${message} &r&f을 획득하셨습니다&r&f&o!&r")
  
function tbox(message, event) {
  cancel(event)
  ChatLib.chat(" &8❒ " + message)
}





register("chat", "newu")
  .setCriteria(" &b&l[신규유저] &7&l- &f&l${name} &f님이 RPG서버에 처음 접속하셨습니다! &d&l&o[${message}명]&r")
  
function newu(name, message, event) {
  cancel(event)
  ChatLib.chat(" &dNew &eNo." + message + " &7" + name)
}



register("chat", "ranbox")
.setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &6&l&o<&f&l&o랜덤박스&6&l&o> &e${name} &7&l>&7>&l> ${message}")

function ranbox(name, message, event) {
cancel(event)
ChatLib.chat(" &7" + name + " &6❒ " + message)
}


register("chat", "drop1")
  .setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &b${name}&f님이 ${message}을 전리품으로 획득하셨습니다!${m1}")
  
function drop1(name, message, event) {
  cancel(event)
  ChatLib.chat(" &7" + name + " ✦ " + message)
}
register("chat", "drop2")
  .setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &b${name}&f님이 ${message}를 전리품으로 획득하셨습니다!${m1}")
  
function drop2(name, message, event) {
  cancel(event)
  ChatLib.chat(" &7" + name + " ✦ " + message)
}





register("chat", "upu")
  .setCriteria(" &f&l[ &6&lR&b&lD &f&l] &7&l- &f&l${name} &f님이 ${message} &f계급으로 상승하셨습니다.&r")
  
function upu(name, message, event) {
  cancel(event)
  ChatLib.chat(" &7" + name + " ➜ " + message)
}




register("chat", "vlg")
  .setCriteria(" &r&f&l[ &r&6&lR&r&b&lD &r&f&l] &r&7&l- &r&f마을 입구로 이동했습니다. &r&6&o(${message})&r")
  
function vlg(message, event) {
  cancel(event)
  HpDisplay.setLine(0,
    " &6" + message + "  "
  )
  HpDisplay.setLine(1,
    ""
  )
  HpDisplay.setLine(2,
    ""
  )
  HpDisplay.setLine(3,
    ""
  )
}





register("chat", "mbsk")
  .setCriteria(" &8&l&o(&6&l&oMINIBOSS&8&l&o) &7&l- ${message} &f이 &7${name}&f님에 의하여 처치 되었습니다!&r")
  
function mbsk(name, message, event) {
  cancel(event)
  ChatLib.chat(" &7" + message + " &c⚔ &7" + name)
}

register("chat", "mbsk2")
  .setCriteria(" &8&l&o(&6&l&oMINIBOSS&8&l&o) &7&l- ${message} &f가 &7${name}&f님에 의하여 처치 되었습니다!&r")
  
function mbsk2(name, message, event) {
  cancel(event)
  ChatLib.chat(" &7" + message + " &c⚔ &7" + name)
}

register("chat", "mbss")
  .setCriteria(" &8&l&o(&6&l&oMINIBOSS&8&l&o) &7&l- ${message} &f이 소환 되었습니다!&r")
  
function mbss(message, event) {
  cancel(event)
  ChatLib.chat(" &7✮ " + message)
}

register("chat", "mbss2")
  .setCriteria(" &8&l&o(&6&l&oMINIBOSS&8&l&o) &7&l- ${message} &f가 소환 되었습니다!&r")
  
function mbss2(message, event) {
  cancel(event)
  ChatLib.chat(" &7✮ " + message)
}



register("chat", "cc")
  .setCriteria("${emp1} &f초월에 &a&l성공&f하셨습니다!!${emp2}")
  
function cc() {
  ChatLib.command("ㅈㅊ cc")
}





register("chat", "bosskill")
  .setCriteria("${emp1}&4&l&o(&c&l&oBOSS&4&l&o) &7&l- ${name} &f&l이 &e&l&o${message}&f&l님에 의하여 처치 되었습니다!${emp2}")
  
function bosskill(emp1, name, message, emp2, event) {
  cancel(event)
  HpDisplay.setLine(2,
    emp1 + emp2
  )
  HpDisplay.setLine(2,
    ""
  )
  ChatLib.chat(" &7" + message + " &c⚔ &7" + name)
}

register("chat", "bosskill2")
  .setCriteria("${emp1}&4&l&o(&c&l&oBOSS&4&l&o) &7&l- ${name} &f&l가 &e&l&o${message}&f&l님에 의하여 처치 되었습니다!${emp2}")
  
function bosskill2(emp1, name, message, emp2, event) {
  cancel(event)
  HpDisplay.setLine(2,
    emp1 + emp2
  )
  HpDisplay.setLine(2,
    ""
  )
  ChatLib.chat(" &7" + message + " &c⚔ &7" + name)
}



register("chat", "bss")
  .setCriteria("${emp1}&4&l&o(&c&l&oBOSS&4&l&o) &7&l- ${message} &f&l보스가 소환 되었습니다!${emp2}")
  
function bss(emp1, message, emp2, event) {
  cancel(event)
  HpDisplay.setLine(2,
    emp1 + emp2
  )
  HpDisplay.setLine(2,
    ""
  )
  ChatLib.chat(" &c✮ " + message)
}






register("chat", "gks")
  .setCriteria("${emp1}&f&l[ &6&lR&b&lD &f&l] &7&l- &f&l${name} &f님의 ${message} &f각성!${emp2}")
  
function gks(name, message, event) {
  cancel(event)
  ChatLib.chat(" &7" + name + " &e✧ " + message)
}

register("chat", "gksm")
  .setCriteria("${emp1}&f&l[ &6&lR&b&lD &f&l] &7&l- &f&l${name} &f님의 &0&0&0&0&0&0&f&1&7&l${message} &f달성!!${emp2}")
  
function gksm(name, message, event) {
  cancel(event)
  ChatLib.chat(" &7" + name + " &e✦ " + message)
}








register("chat", "from")
  .setCriteria(" &6&l[ &e&l${name} &6&l-> &e&l나 &6&l] &f${message}&r")
  
function from(name, message, event) {
  cancel(event)
  ChatLib.chat(" &dFrom. &7" + name + ": " + message)
}


register("chat", "to")
  .setCriteria(" &6&l[ &e&l나 &6&l-> &e&l${name} &6&l] &f${message}&r")
  
function to(name, message, event) {
  cancel(event)
  ChatLib.chat(" &dTo. &7" + name + ": " + message)
}









register("chat", "empty")
  .setCriteria("  &r&f슬라임 빌리지&r&7(시작 마을)&r&f로 되돌아가려면&r")


register("chat", "empty")
  .setCriteria("  &r&7[ &r&f/슬라임빌리지 &r&7] &r&f명령어를 입력해주세요.&r")
  
function empty(event) {
  cancel(event)
}







// register("chat", "myChat2")
//   .setCriteria(" 장사글을 다시 사용하실 수 있습니다.")
  
// function myChat2(event) {
//   cancel(event)
//   ChatLib.command("장사글 ㅍㅍ 노각 워터노바 53 ㅍㅍ")
// }


register("command", "myCommand")
    .setName("shop")
function myCommand() {
    ChatLib.command("상점")
}

























// register("chat", (message) => {
// 	ChatLib.command('pc P>IlyIce: ' + message)
// 	ChatLib.command('gc P>IlyIce: ' + message)
// }).setCriteria("Party > [MVP+] IlyIce: ${message}").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc DM>IlyIce: ' + message)
// 	ChatLib.command('gc DM>IlyIce: ' + message)
// }).setCriteria("From [MVP+] IlyIce: ${message}").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc G>IlyIce: ' + message)
// 	ChatLib.command('gc G>IlyIce: ' + message)
// }).setCriteria("Guild > [MVP+] IlyIce [GM]: ${message}").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc O>IlyIce: ' + message)
// 	ChatLib.command('gc O>IlyIce: ' + message)
// }).setCriteria("Officer > [MVP+] IlyIce [GM]: ${message}").setContains();

// register("chat", (player, message) => {
// 	ChatLib.command('pc A>IlyIce: ' + message)
// 	ChatLib.command('gc A>IlyIce: ' + message)
// }).setCriteria(" + ${player} [MVP+] IlyIce: ${message}").setContains();


// register("chat", (message) => {
// 	ChatLib.command('pc 아이스: ' + message)
// }).setCriteria("Party > [MVP+] IlyIce: ${message}").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc 키울이: ' + message)
// }).setCriteria("Party > [MVP+] Ilylce: ${message}").setContains();



// register("chat", (message) => {
// 	ChatLib.command('pc [Treasure] 우와~!! ' + message + '(이)라는 보물을 낚았어!')
// }).setCriteria("You caught ${message}, that's a treasure!").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc [Fish] 오예! ' + message + '(을)를 낚았어!')
// }).setCriteria("You caught a ${message}!").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc [Treasure] 우와~!! ' + message + '(이)라는 보물을 낚았어!')
// }).setCriteria("You caught ${message}, that's a treasure!").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc [Trash] 으악! ' + message + '(을)를 낚았어. ㅠㅠ')
// }).setCriteria("Oh no, you caught ${message}!").setContains();

// register("chat", (message) => {
// 	ChatLib.command('pc [Special] 우와~!!! 스페셜 물고기 ' + message + '(을)를 낚았어!!!!!')
// }).setCriteria("Wow, you caught a ${message}!").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc 네?')
// }).setCriteria("Party > ${player} 목살").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 네?')
// }).setCriteria("Guild > ${player} 목살").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 네?')
// }).setCriteria("From ${player} 목살").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc 뭐')
// }).setCriteria("Party > ${player} 야").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 뭐')
// }).setCriteria("Guild > ${player} 야").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 뭐')
// }).setCriteria("From ${player} 야").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc 하하하')
// }).setCriteria("Party > ${player} ㅋ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 하하하')
// }).setCriteria("Guild > ${player} ㅋ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 하하하')
// }).setCriteria("From ${player} ㅋ").setContains();




// register("chat", (player) => {
// 	ChatLib.command('pc 하하하')
// }).setCriteria("Party > ${player} z").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 하하하')
// }).setCriteria("Guild > ${player} z").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 하하하')
// }).setCriteria("From ${player} z").setContains();




// register("chat", (player) => {
// 	ChatLib.command('pc !')
// }).setCriteria("Party > ${player} ?").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc !')
// }).setCriteria("Guild > ${player} ?").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r !')
// }).setCriteria("From ${player} ?").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc ㅠㅠ 나 병!신 아니야')
// }).setCriteria("Party > ${player} ㅄ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc ㅠㅠ 나 병!신 아니야')
// }).setCriteria("Guild > ${player} ㅄ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r ㅠㅠ 나 병!신 아니야')
// }).setCriteria("From ${player} ㅄ").setContains();


// register("chat", (player) => {
// 	ChatLib.command('pc ㅠㅠ 나 병!신 아니야')
// }).setCriteria("Party > ${player} 병신").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc ㅠㅠ 나 병!신 아니야')
// }).setCriteria("Guild > ${player} 병신").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r ㅠㅠ 나 병!신 아니야')
// }).setCriteria("From ${player} 병신").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc ㅠㅠ 나 병!신 아니야')
// }).setCriteria("Party > ${player} ㅂㅅ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc ㅠㅠ 나 병!신 아니야')
// }).setCriteria("Guild > ${player} ㅂㅅ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r ㅠㅠ 나 병!신 아니야')
// }).setCriteria("From ${player} ㅂㅅ").setContains();


// register("chat", (player) => {
// 	ChatLib.command('pc 욕은나빠!!!!!!!!!!!!!!!')
// }).setCriteria("Party > ${player} ㅗ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 욕은나빠!!!!!!!!!!!!!!!')
// }).setCriteria("Guild > ${player} ㅓ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 욕은나빠!!!!!!!!!!!!!!!')
// }).setCriteria("From ${player} ㅗ").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc 욕하지말아주세용...')
// }).setCriteria("Party > ${player} ㅅㅂ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 욕하지말아주세용...')
// }).setCriteria("Guild > ${player} ㅅㅂ").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 욕하지말아주세용...')
// }).setCriteria("From ${player} ㅅㅂ").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc 욕하지말아주세용...')
// }).setCriteria("Party > ${player} tq").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 욕하지말아주세용...')
// }).setCriteria("Guild > ${player} tq").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 욕하지말아주세용...')
// }).setCriteria("From ${player} tq").setContains();



// register("chat", (player) => {
// 	ChatLib.command('pc 내가 좀 큐티하긴 하징 ><')
// }).setCriteria("Party > ${player} qt").setContains();

// register("chat", (player) => {
// 	ChatLib.command('gc 내가 좀 큐티하긴 하징 ><')
// }).setCriteria("Guild > ${player} qt").setContains();

// register("chat", (player) => {
// 	ChatLib.command('r 내가 좀 큐티하긴 하징 ><')
// }).setCriteria("From ${player} qt").setContains();




// register("chat", (player) => {
// 	ChatLib.command('pc 나도! 동일한! 대우를! 받아야! 한다!')
// }).setCriteria("Invalid usage! Use: /msg (player) (message)").setContains();

// register("chat", (player) => {
// 	ChatLib.command('pc 나도! 동일한! 대우를! 받아야! 한다!')
// }).setCriteria("Party > [MVP+] choco_moxal: 나도! 동일한! 대우를! 받아야! 한다!").setContains();





// When use /ct load or reload
//ChatLib.chat(`&6[✯] &e리붓되었습니다.`)